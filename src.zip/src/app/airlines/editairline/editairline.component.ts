import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editairline',
  templateUrl: './editairline.component.html',
  styleUrls: ['./editairline.component.scss']
})
export class EditairlineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
