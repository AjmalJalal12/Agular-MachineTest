import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airline-list',
  templateUrl: './airline-list.component.html',
  styleUrls: ['./airline-list.component.scss']
})
export class AirlineListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
