export class Airline {
    flightId: number=0;
    flightName: string='';
    depAirport: string='';
    depDate: Date = new Date;
    depTime: string='';
    arrAirport: string='';
    arrDate: Date = new Date;
    arrTime: string='';


     
}


